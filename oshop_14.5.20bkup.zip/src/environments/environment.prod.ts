export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyBHy6nnypBj8UmrY7oRuVv4znQKF6dfxWo",
    authDomain: "oshop-2ccbb.firebaseapp.com",
    databaseURL: "https://oshop-2ccbb.firebaseio.com",
    projectId: "oshop-2ccbb",
    storageBucket: "oshop-2ccbb.appspot.com",
    messagingSenderId: "59526223429",
    appId: "1:59526223429:web:e5870b20b830aa3306b52c",
    measurementId: "G-CVK9YPGFKB"
  }
};
